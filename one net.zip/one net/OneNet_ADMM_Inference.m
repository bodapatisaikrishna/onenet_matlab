% OneNet ADMM Inference Engine -
    MNIST Configuration %
        This script demonstrates solving an inverse problem(Inpainting) using %
        the trained OneNet Projector and ADMM optimization.

        % % 1. Load Trained Model modelFile = 'OneNet_Trained_Models.mat';

if exist (modelFile, 'file')
  load(modelFile, 'netG');
disp('Loaded trained Generator.');
else warning('Trained model not found. Please run OneNet_Training.m first.');
    % Initialize a random net for demo purposes
    run('OneNet_Model.m');
    disp('Initialized random Generator for demonstration.');
    end

            % % 2. Load Test Image(MNIST Digit) % Try to get a digit image
        or generate random 28x28 try % Try to load a specific digit
               if available (e.g., from shipping dataset) digitDir =
        fullfile(matlabroot, 'toolbox', 'nnet', 'nndemos', 'nndatasets',
                 'DigitDataset', '5');
    digitFiles = dir(fullfile(digitDir, '*.png'));

    if
      ~isempty(digitFiles) img = imread(fullfile(digitFiles(1).folder,
                                                 digitFiles(1).name));
    else
      % Fallback to peppers if digits not found,
          but resize strictly to 28x28 img = imread('peppers.png');
    end catch warning('Image loading failed. Using random 28x28 pattern.');
    img = rand(28, 28);
    end

            % Check if image is RGB and convert to Grayscale if size (img, 3) ==
        3 img = rgb2gray(img);
    end

        % Resize to 28x28(MNIST size)img = imresize(img, [28 28]);
    img = double(img);
    if max (img( :))
      > 1 img = img / 255; % Normalize to [0, 1]
end

% Preprocess for network: [-1, 1]
img_input = (img - 0.5) * 2;

    % %
        3. Setup Inverse Problem
        : Inpainting %
          Define a masking operator A %
          Create a random mask(dropping 50 % of pixels) mask = rand(size(img)) >
                                                               0.5;

    % Corrupt image(Element - wise multiplication) y = img_input.*mask;

    figure('Name', 'OneNet Inference (MNIST 28x28)');
    subplot(1, 3, 1);
    imshow(img);
    title('Original');
    subplot(1, 3, 2);
% Rescale for display: [-1,1] -> [0,1]
imshow((y/2)+0.5);
title('Corrupted (Input)');

% % 4. ADMM Optimization % Goal : min_x || y - A(x) ||
    ^2 + I_X(x) % A is point -
        wise multiplication by mask.

            % Parameters rho = 0.1;
% Penalty parameter(tune this !) numIterations = 50;

% Initialization x = randn(size(y));
z = x;
% Initial estimate u = zeros(size(x));

disp('Starting ADMM Reconstruction...');

for k = 1:numIterations
    
    % --- Step 1: x-update (Inversion) ---
    % Analytical solution for Inpainting:
    % x = (M^T y + rho(z - u)) / (M^T M + rho I)
    
    numerator = y + rho * (z - u);
denominator = mask + rho;

x = numerator./ denominator;

% -- -Step 2 : z - update(Projection)-- - % z = Projector(x + u)

    input_z = x + u;

    % Convert to dlarray for network [H, W, C, B]
    % Input is 28x28, need 28x28x1x1
    dl_input = dlarray(single(input_z), 'SSCB');

    % Forward pass(predict projection) dl_output = forward(netG, dl_input);

    % Extract data z = double(extractdata(dl_output));

    % -- -Step 3 : u - update(Multiplier)-- - u = u + x - z;

    % -- -Monitor Convergence-- - % Calculate residual || x - z || residual =
        norm(x( :) - z( :));

    % if mod (k, 10) ==
        0 % fprintf('Iteration %d: Residual = %.4f\n', k, residual);
    % end
end

%% 5. Visualization
% Post-process for display
recon_img = (z / 2) + 0.5;
    recon_img = max(0, min(1, recon_img));
    % Clip to[0, 1]

        subplot(1, 3, 3);
    imshow(recon_img);
    title('Reconstructed');

    disp('Reconstruction Complete.');
