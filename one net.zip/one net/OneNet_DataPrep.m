% OneNet Data Preparation - MNIST Configuration
% This script sets up the data loading pipeline for the OneNet framework using MNIST.

%% 1. Setup Image Data Directory
% For MNIST, we can often use MATLAB's digit dataset as a proxy or load custom 28x28 data.
% If you have the specific 'randomly deformed MNIST' files, point dataDir to them.
% Otherwise, we will use the shipping digit dataset and resize/format it to 28x28.

% Default: Use shipping digit images
dataDir = fullfile(matlabroot, 'toolbox', 'nnet', 'nndemos', 'nndatasets', 'DigitDataset');

%
    If user provided a path(uncomment to use)
    : % dataDir = '/path/to/mnist/images';

if
  ~exist(dataDir, 'dir')
      warning('MNIST data directory not found at default location: %s',
              dataDir);
% Fallback to standard imdata if DigitDataset is missing,
    but resize to 28x28 dataDir =
        fullfile(matlabroot, 'toolbox', 'images', 'imdata');
disp(['Falling back to: ' dataDir ' (Images will be resized to 28x28)']);
else disp(['Using data from: ' dataDir]);
end

    % % 2. Create Image Datastore imds =
    imageDatastore(dataDir, ... 'IncludeSubfolders', true, ... 'FileExtensions',
                   {'.jpg', '.jpeg', '.png', '.bmp', '.tif'});

% Shuffle the datastore imds = shuffle(imds);

% % 3. Preprocessing Functions % MNIST Standard Size targetSize = [28 28];

% Augmentation pipeline (Optional, but often good for generalization)
augmenter = imageDataAugmenter(...
    'RandXReflection', false, ... % MNIST digits shouldn't be flipped horizontally usually
    'RandRotation', [-10 10], ...
    'RandScale', [0.9 1.1]);

% Create a combined datastore with resizing %
    We use a helper function to resize and normalize images to
        range[-1, 1] dsTrain =
    transform(imds, @(x) preprocessImages(x, targetSize));

% % 4. Visualize a Batch %
    Read a few images to verify if dsTrain has data if hasdata (dsTrain)
        data = read(dsTrain);
% Handle cell output from transform if iscell (data) if iscell (data{1}) data =
    cat(4, data{ : });
else data = data{1};
end end

    figure;
    % Remap [-1, 1] back to [0, 1] for display
    montage((data/2) + 0.5);
    title('Preprocessed MNIST Samples (28x28)');
    drawnow;
    else warning('No images found in dataset.');
    end

        % %
        Helper Function
        : Preprocess Images function out =
        preprocessImages(in, targetSize) % Browse converts to cell,
                                     so handle cell input if iscell (in) in =
                                         in{1};
    end

            % Force Grayscale if RGB if size (in, 3) ==
        3 in = rgb2gray(in);
    end

        % Resize to 28x28 img = imresize(in, targetSize);

    % Convert to single img = single(img);

    % Normalize to[0, 1] if not already % MNIST images might be[0, 255] or
        [ 0, 1 ] if max (img( :)) > 1 img = img / 255;
    end
    
    % Normalize to [-1, 1] for Tanh output
    out = (img - 0.5) * 2;
    end
