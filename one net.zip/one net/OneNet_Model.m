% OneNet Model Definitions - MNIST Configuration
% This script defines the Generator (Projector) and Discriminator networks.
% Configured for 28x28 Input and Simplified Architecture.

%% 1. Define the Projector (Generator)
Network lgraphG = layerGraph();

% Input Layer : 28x28x1(Grayscale)inputLayer = imageInputLayer([28 28 1],
                                                               'Name', 'input',
                                                               'Normalization',
                                                               'none');
lgraphG = addLayers(lgraphG, inputLayer);

% Initial Convolution conv1 =
    convolution2dLayer(3, 32, 'Padding', 'same', 'Name', 'conv1');
% Reduced filters to 32 relu1 = reluLayer('Name', 'relu1');
lgraphG = addLayers(lgraphG, [ conv1, relu1 ]);
lgraphG = connectLayers(lgraphG, 'input', 'conv1');

% Add Residual Blocks %
    Simplified : Reduced number of blocks from 6 to 3 to
                 "remove upper layers" numResBlocks = 3;
lastLayerName = 'relu1';

for
  i = 1 : numResBlocks resBlockName = sprintf('res%d', i);

% Convolution 1 c1 =
    convolution2dLayer(3, 32, 'Padding', 'same', 'Name', [resBlockName '_c1']);
bn1 = batchNormalizationLayer('Name', [resBlockName '_bn1']);
r1 = reluLayer('Name', [resBlockName '_r1']);

% Convolution 2 c2 =
    convolution2dLayer(3, 32, 'Padding', 'same', 'Name', [resBlockName '_c2']);
bn2 = batchNormalizationLayer('Name', [resBlockName '_bn2']);

% Addition add = additionLayer(2, 'Name', [resBlockName '_add']);

% Add layers to graph lgraphG =
    addLayers(lgraphG, [ c1, bn1, r1, c2, bn2, add ]);

% Connect input of block to c1 lgraphG =
    connectLayers(lgraphG, lastLayerName, [resBlockName '_c1']);

% Connect internal layers lgraphG =
    connectLayers(lgraphG, [resBlockName '_c1'], [resBlockName '_bn1']);
lgraphG = connectLayers(lgraphG, [resBlockName '_bn1'], [resBlockName '_r1']);
lgraphG = connectLayers(lgraphG, [resBlockName '_r1'], [resBlockName '_c2']);
lgraphG = connectLayers(lgraphG, [resBlockName '_c2'], [resBlockName '_bn2']);

% Connect to addition(Residual path) lgraphG =
    connectLayers(lgraphG, [resBlockName '_bn2'], [resBlockName '_add/in1']);

% Connect Skip connection lgraphG =
    connectLayers(lgraphG, lastLayerName, [resBlockName '_add/in2']);

lastLayerName = [resBlockName '_add'];
end

    % Final Convolution to map back to image space convFinal =
    convolution2dLayer(3, 1, 'Padding', 'same', 'Name', 'convFinal');
tanhFinal = tanhLayer('Name', 'tanhFinal');
% Output in range[-1, 1]

    lgraphG = addLayers(lgraphG, [ convFinal, tanhFinal ]);
lgraphG = connectLayers(lgraphG, lastLayerName, 'convFinal');

% Create dlnetwork netG = dlnetwork(lgraphG);

% % 2. Define the Discriminator Network %
    Simplified Discriminator
    : Removed upper
      layers(reduced from 3 blocks to 2) lgraphD = layerGraph();

inputD = imageInputLayer([28 28 1], 'Name', 'inputD', 'Normalization', 'none');
lgraphD = addLayers(lgraphD, inputD);

% Block 1 c1 =
    convolution2dLayer(4, 32, 'Stride', 2, 'Padding', 'same', 'Name', 'd_c1');
l1 = leakyReluLayer(0.2, 'Name', 'd_l1');
lgraphD = addLayers(lgraphD, [ c1, l1 ]);
lgraphD = connectLayers(lgraphD, 'inputD', 'd_c1');

% Block 2 c2 =
    convolution2dLayer(4, 64, 'Stride', 2, 'Padding', 'same', 'Name', 'd_c2');
bn2 = batchNormalizationLayer('Name', 'd_bn2');
l2 = leakyReluLayer(0.2, 'Name', 'd_l2');
lgraphD = addLayers(lgraphD, [ c2, bn2, l2 ]);
lgraphD = connectLayers(lgraphD, 'd_l1', 'd_c2');

% Block 3 (Reduced/Removed depth for simplicity/MNIST)
% Kept shallow for 28x28 input

% Output Probability
cOut = convolution2dLayer(4, 1, 'Padding', 'same', 'Name', 'd_cOut');
sig = sigmoidLayer('Name', 'sigmoid');

lgraphD = addLayers(lgraphD, [ cOut, sig ]);
lgraphD = connectLayers(lgraphD, 'd_l2', 'd_cOut');

% Create dlnetwork netD = dlnetwork(lgraphD);

% % 3. Summary disp('Generator Network Constructed (28x28 Input, 3 ResBlocks)');
disp('Discriminator Network Constructed (28x28 Input, 2 ConvBlocks)');
