% OneNet Training Loop -
    MNIST Configuration %
        This
            script implements the adversarial training of the Projector network.

        % % 1. Load Data and Models %
        Ensure DataPrep and
            Model setup scripts are available if ~exist('dsTrain', 'var')
                disp('Running Data Preparation...');
run('OneNet_DataPrep.m');
end

    if ~exist('netG', 'var') ||
    ~exist('netD', 'var') disp('Running Model Definition...');
run('OneNet_Model.m');
end

    % % 2. Training Configuration totalIterations = 80000;
% Requested by user miniBatchSize = 32;
% Requested by user learnRate = 0.0002;
gradientDecayFactor = 0.5;
squaredGradientDecayFactor = 0.999;
lambdaRec = 10; % Weight for reconstruction loss

% Calculate Epochs
% If dsTrain is a transformed Datastore, getting numFiles might need underlying datastore
if isprop(dsTrain, 'UnderlyingDatastores')
    uDS = dsTrain.UnderlyingDatastores{1};
numFiles = numel(uDS.Files);
else % Fallback estimate if we can't get exact count easily numFiles = 10000; % Default for MNIST subset validation
end

iterationsPerEpoch = ceil(numFiles / miniBatchSize);
numEpochs = ceil(totalIterations / iterationsPerEpoch);

disp(['Configuration: Batch Size = ' num2str(miniBatchSize)]);
disp(['Configuration: Total Iterations = ' num2str(totalIterations)]);
disp(['Configuration: Estimated Epochs = ' num2str(numEpochs)]);

% Optimizers avgG = [];
avgSqG = [];
avgD = [];
avgSqD = [];

% Initialize training plot figure;
lineLossG = animatedline('Color', 'g');
lineLossD = animatedline('Color', 'r');
legend('Generator Loss', 'Discriminator Loss');
xlabel("Iteration");
ylabel("Loss");
grid on;

% % 3. Training Loop iteration = 0;
epoch = 1;

% minibatchqueue Setup
% Ensure PartialMiniBatch is 'discard' to keep batch size constant at 32 for stability
mbq = minibatchqueue(dsTrain, ...
    'MiniBatchSize', miniBatchSize, ...
    'PartialMiniBatch', 'discard', ...
    'MiniBatchFcn', @preprocessMiniBatch, ...
    'MiniBatchFormat', 'SSCB');

disp('Starting training...');

while
  iteration < totalIterations reset(mbq);

while
  hasdata(mbq) iteration = iteration + 1;

% Read batch of real images X = next(mbq);

% Generate perturbed images(X_tilde)
with Gaussian noise noise = 0.1 * randn(size(X), 'like', X);
X_tilde = X + dlarray(noise, 'SSCB');

% Evaluate model gradients
        and losses[gradientsG, gradientsD, stateG, stateD, lossG, lossD] =
    ... dlfeval(@modelGradients, netG, netD, X, X_tilde, lambdaRec);

% Update network states(Batch Normalization statistics) netG.State = stateG;
netD.State = stateD;

% Update Discriminator[netD, avgD, avgSqD] =
    adamupdate(netD, gradientsD, ... avgD, avgSqD, iteration, learnRate,
               gradientDecayFactor, squaredGradientDecayFactor);

% Update Generator[netG, avgG, avgSqG] =
    adamupdate(netG, gradientsG, ... avgG, avgSqG, iteration, learnRate,
               gradientDecayFactor, squaredGradientDecayFactor);

% Plot progress if mod (iteration, 50) ==
    0 % Use gather to pull data from GPU if needed D_loss_val =
    double(gather(extractdata(lossD)));
G_loss_val = double(gather(extractdata(lossG)));

addpoints(lineLossG, iteration, G_loss_val);
addpoints(lineLossD, iteration, D_loss_val);
drawnow;
end

        % Stop if we hit user requested total iterations if iteration >=
    totalIterations break;
end end

    disp(['Epoch ' num2str(epoch) ' complete. Iteration: ' num2str(iteration)]);
epoch = epoch + 1;
end

    % Save trained models save('OneNet_Trained_Models.mat', 'netG', 'netD');
disp('Training complete. Models saved.');

% %
    Helper Functions

        function X = preprocessMiniBatch(data) %
                     Concatenate cell array to 4D array X = cat(4, data{ : });
% Ensure it is a dlarray X = dlarray(X, 'SSCB');
end

    function[gradG, gradD, stateG, stateD, lossG, lossD] =
        modelGradients(netG, netD, X, X_tilde, lambdaRec)

            % -- -Generator Forward Pass-- -
        % Generate projected(fake)
images from perturbed input[Y_fake, stateG] = forward(netG, X_tilde);

% -- -Discriminator Forward Pass-- - % Real images[predictionsReal, stateD] =
    forward(netD, X);

% Fake images predictionsFake = forward(netD, Y_fake);

% -- -Calculate Losses-- - epsilon = 1e-8;

% Discriminator Loss : Maximize log(D(x)) +
    log(1 - D(G(z))) % Minimizing : -log(D(x)) -
    log(1 - D(G(z))) lossD_Real = -mean(log(predictionsReal + epsilon));
lossD_Fake = -mean(log(1 - predictionsFake + epsilon));
lossD = lossD_Real + lossD_Fake;

% Generator Loss : Minimize -
    log(D(G(z))) lossG_Adv = -mean(log(predictionsFake + epsilon));

% Reconstruction Loss lossG_Rec = mse(Y_fake, X);

lossG = lossG_Adv + lambdaRec * lossG_Rec;

% -- -Calculate Gradients-- - gradD = dlgradient(lossD, netD.Learnables);
gradG = dlgradient(lossG, netG.Learnables);
end
