

import numpy as np

def vec(x):
    return np.reshape(x, (-1), order='F')